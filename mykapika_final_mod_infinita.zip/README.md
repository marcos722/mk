# mykapika - versão final focada na picareta e no sensor

Base de código-fonte para NeoForge 1.21.1.

## O que esta versão faz
- item final: `mykapika:cosmic_sensor_pickaxe`
- textura final em `assets/mykapika/textures/item/cosmic_sensor_pickaxe.png`
- model final em `assets/mykapika/models/item/cosmic_sensor_pickaxe.json`
- detecção de minérios usando `BlockTags.ORES`
- varredura por ticks com limite de raio
- overlay 2D na tela com marcadores estilo referência

## Estrutura dos assets
- `src/main/resources/assets/mykapika/models/item/cosmic_sensor_pickaxe.json`
- `src/main/resources/assets/mykapika/textures/item/cosmic_sensor_pickaxe.png`
- `src/main/resources/assets/mykapika/lang/en_us.json`

## Observações
- A textura foi convertida para PNG real a partir da imagem enviada.
- O tooltip sem nome amigável é resolvido adicionando lang, como neste pacote.
- Dependendo da build exata do NeoForge 21.1.x, talvez você precise ajustar import/assinatura do evento de render GUI e da projeção da câmera.
- Esta entrega é código-fonte para você compilar no seu ambiente.

- Esta versão foi ajustada para durabilidade infinita, removendo `durability(...)` do registro do item.
