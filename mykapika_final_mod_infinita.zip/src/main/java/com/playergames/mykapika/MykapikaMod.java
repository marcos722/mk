package com.playergames.mykapika;

import com.playergames.mykapika.registry.ModItems;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

@Mod(MykapikaMod.MOD_ID)
public class MykapikaMod {
    public static final String MOD_ID = "mykapika";

    public MykapikaMod(IEventBus modBus) {
        ModItems.ITEMS.register(modBus);
    }
}
