package com.playergames.mykapika.registry;

import com.playergames.mykapika.MykapikaMod;
import com.playergames.mykapika.item.CosmicSensorPickaxeItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MykapikaMod.MOD_ID);

    public static final DeferredItem<Item> COSMIC_SENSOR_PICKAXE = ITEMS.register(
            "cosmic_sensor_pickaxe",
            () -> new CosmicSensorPickaxeItem(new Item.Properties().stacksTo(1))
    );
}
