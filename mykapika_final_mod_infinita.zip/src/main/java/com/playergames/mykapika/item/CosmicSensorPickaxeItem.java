package com.playergames.mykapika.item;

import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.DiggerItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.level.block.state.BlockState;

public class CosmicSensorPickaxeItem extends DiggerItem {
    public CosmicSensorPickaxeItem(Properties properties) {
        super(Tiers.DIAMOND, BlockTags.MINEABLE_WITH_PICKAXE, properties);
    }

    public static boolean isSensorPickaxe(ItemStack stack) {
        return !stack.isEmpty() && stack.getItem() instanceof CosmicSensorPickaxeItem;
    }

    public static boolean isOre(BlockState state) {
        return state.is(BlockTags.ORES);
    }
}
