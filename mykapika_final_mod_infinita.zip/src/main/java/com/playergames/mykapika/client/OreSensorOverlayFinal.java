package com.playergames.mykapika.client;

import com.playergames.mykapika.MykapikaMod;
import com.playergames.mykapika.item.CosmicSensorPickaxeItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@EventBusSubscriber(modid = MykapikaMod.MOD_ID, value = Dist.CLIENT)
public class OreSensorOverlayFinal {
    private static final int RADIUS_XZ = 16;
    private static final int RADIUS_Y = 8;
    private static final int SCAN_INTERVAL = 6;
    private static final int MAX_MARKERS = 24;
    private static final List<BlockPos> ORES = new ArrayList<>();
    private static int tickCounter = 0;

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        Level level = mc.level;
        if (player == null || level == null) {
            ORES.clear();
            return;
        }

        boolean holding = CosmicSensorPickaxeItem.isSensorPickaxe(player.getMainHandItem()) || CosmicSensorPickaxeItem.isSensorPickaxe(player.getOffhandItem());
        if (!holding) {
            ORES.clear();
            tickCounter = 0;
            return;
        }

        tickCounter++;
        if (tickCounter < SCAN_INTERVAL) return;
        tickCounter = 0;

        ORES.clear();
        BlockPos center = player.blockPosition();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        for (int y = -RADIUS_Y; y <= RADIUS_Y; y++) {
            for (int x = -RADIUS_XZ; x <= RADIUS_XZ; x++) {
                for (int z = -RADIUS_XZ; z <= RADIUS_XZ; z++) {
                    pos.set(center.getX() + x, center.getY() + y, center.getZ() + z);
                    BlockState state = level.getBlockState(pos);
                    if (state.is(BlockTags.ORES)) {
                        ORES.add(pos.immutable());
                    }
                }
            }
        }

        ORES.sort(Comparator.comparingDouble(p -> p.distSqr(center)));
        if (ORES.size() > MAX_MARKERS) {
            ORES.subList(MAX_MARKERS, ORES.size()).clear();
        }
    }

    @SubscribeEvent
    public static void onRenderGui(RenderGuiLayerEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || ORES.isEmpty()) return;

        boolean holding = CosmicSensorPickaxeItem.isSensorPickaxe(player.getMainHandItem()) || CosmicSensorPickaxeItem.isSensorPickaxe(player.getOffhandItem());
        if (!holding) return;

        GuiGraphics gui = event.getGuiGraphics();
        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();

        Matrix4f view = new Matrix4f(mc.gameRenderer.getMainCamera().rotation());
        view.rotateX((float)Math.PI);
        Matrix4f proj = mc.gameRenderer.getProjectionMatrix(mc.gameRenderer.getMainCamera(), event.getPartialTick());

        for (BlockPos pos : ORES) {
            double dx = pos.getX() + 0.5 - mc.gameRenderer.getMainCamera().getPosition().x;
            double dy = pos.getY() + 0.5 - mc.gameRenderer.getMainCamera().getPosition().y;
            double dz = pos.getZ() + 0.5 - mc.gameRenderer.getMainCamera().getPosition().z;

            Vector4f v = new Vector4f((float)dx, (float)dy, (float)dz, 1.0F);
            v.mul(view);
            v.mul(proj);
            if (v.w <= 0.1f) continue;

            float ndcX = v.x / v.w;
            float ndcY = v.y / v.w;
            int screenX = (int)((ndcX * 0.5f + 0.5f) * sw);
            int screenY = (int)((-ndcY * 0.5f + 0.5f) * sh);

            if (screenX < -50 || screenX > sw + 50 || screenY < -50 || screenY > sh + 50) continue;

            double dist = Math.sqrt(pos.distSqr(player.blockPosition()));
            int size = dist < 6 ? 13 : dist < 12 ? 11 : 9;
            drawMarker(gui, screenX, screenY, size);
        }
    }

    private static void drawMarker(GuiGraphics gui, int x, int y, int size) {
        int border = 0xFFFFFFFF;
        int fill = 0x88000000;
        int core = 0xFF6FFFF1;
        int s = size;

        gui.fill(x - s, y - s, x + s, y - s + 2, border);
        gui.fill(x - s, y + s - 2, x + s, y + s, border);
        gui.fill(x - s, y - s, x - s + 2, y + s, border);
        gui.fill(x + s - 2, y - s, x + s, y + s, border);

        gui.fill(x - (s - 3), y - (s - 3), x + (s - 3), y + (s - 3), fill);
        gui.fill(x - 3, y - 3, x + 3, y + 3, core);
        gui.fill(x - 1, y - 5, x + 1, y - 3, core);
        gui.fill(x - 5, y - 1, x - 3, y + 1, core);
        gui.fill(x + 3, y - 1, x + 5, y + 1, core);
        gui.fill(x - 1, y + 3, x + 1, y + 5, core);
    }
}
